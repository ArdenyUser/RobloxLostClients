local NetworkServer = game:service("NetworkServer")
NetworkServer:start(53640)

local RunService = game:service("RunService")
RunService:run()